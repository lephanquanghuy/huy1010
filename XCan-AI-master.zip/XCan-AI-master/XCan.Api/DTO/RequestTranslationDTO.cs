﻿namespace XCan.Api.DTO
{
    public class RequestTranslationDTO
    {
        public string ExtractedContent { get; set; }
        public string Base64Img { get; set; }
    }
}
