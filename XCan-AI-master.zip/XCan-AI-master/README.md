# © 2024 Phan Xuan Quang / XCan AI
------------
An Generative AI-accelerated web application that is used to OCR/extract the text from any images without changing the format of the text

![Image](https://i.imgur.com/xXga9lT.png)

*Coming soon . . .*
